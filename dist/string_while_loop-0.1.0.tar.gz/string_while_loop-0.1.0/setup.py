from setuptools import setup

setup(
   name='string_while_loop',
   version='0.1.0',
   packages=['string_while_loop'],
   description='This is string_while_loop Test',
   install_requires=[
       "requests",
   ]
)